<template>
  <div>
    <h1>Test.vue 测试组件</h1>
  </div>
</template>
<script>
  export default {
    data(){
      return {}
    }
  }  
</script>
<style>
</style>